<template>
	<div>
		二级菜单
	</div>
</template>
<script>
	export default{
		data(){
			return {
			
			}
		}
	}
</script>