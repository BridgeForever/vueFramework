<style scoped>

    .page-item{
        width: 24px;
        text-align: center;
        line-height: 24px;
        border-left: 1px solid #c1c1c1;
        display: inline-block;
        cursor:pointer;
    }
    .page-item:first-child{
        border-left: none;
    }

    #c-page{
        margin-top: 10px;
        float: left;
        border: 1px solid #c1c1c1;
    }
</style>
<template>
	<div id="monitor">
    <Table border :columns="columns7" v-bind:data="fetData" @on-row-click="goDetail"></Table>
    <!--<Page v-bind:total="totalLength" :page-size=50 @on-change="changePage"></Page>-->

    <Page :total="totalLength" :page-size="pageLength" @on-change="setCurrentPage" show-sizer show-total @on-page-size-change="changePage" :page-size-opts="pageOpts"></Page>
    
    <!--<div id="c-page">
        
        <div class="page-item" v-for = "i in initPage" :indexT = "i"  @click="setCurrentPage(i)" >{{i}}</div>
        
    </div>-->
    </div>
</template>
<script>
import { mapState, mapGetters, mapMutations, mapActions } from 'vuex';
    export default {
        data () {
            return {
                indexPage : 0,
                totalPage:0,
                pageData:[],
                pageLength:100,
                pageOpts:[
                10,20,50,100
                ],
                columns7: [
                    {
                        title:'序号',
                        key:'snapUserFullName',
                        render:(h,params)=>{
                            return params.index+1
                        }

                    },
                    {
                        title: '姓名',
                        key: 'snapUserFullName',
                        render: (h, params) => {
                            return h('div', [
                                h('Icon', {
                                    props: {
                                        type: 'person'
                                    }
                                }),
                                h('strong', params.row.snapUserFullName)
                            ]);
                        }
                    },
                    {
                        title: '部门',
                        key: 'snapDept'
                    },
                    {
                        title: '职位',
                        key: 'snapPost'
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 150,
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h('Button', {
                                    props: {
                                        type: 'primary',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            this.show(params.index)
                                        }
                                    }
                                }, '查看'),
                                h('Button', {
                                    props: {
                                        type: 'error',
                                        size: 'small'
                                    },
                                    on: {
                                        click: () => {
                                            this.remove(params.index)
                                        }
                                    }
                                }, '删除'),
                                h('Dropdown',
                                {
                                	props:{
                                		trigger:"click"
                                	},
                                	on:{
                                	'on-click':()=>{
                                	console.log(1);
                                	}
                                	},
                                	style:{marginLeft:"20px"}
                                },
                                [
                                	h('Button',{
                                		props: {
                                        type: 'primary'
                                   		 }
                                	},'下拉'),
                                	h('Dropdown-menu',
                                	{
                                		slot:"list"
                                		
                                	},[
                                	  h('Dropdown-item',{

                                	  },
                                	  '下拉项')
                                	])
                                ])

                            ]);
                        }
                    }
                ]
            }
        },
        
        computed:{
        	...mapState([
        	'monitor'
        	]),
            
        	totalLength(){
        	return this.monitor.list.length

        	},  
            
            fetData(){
                return this.pageData;
            }
        },
        created(){
        	this.getData();
        },
        beforeUpdate () {
            if(this.pageData.length == 0 && this.monitor.list.length>0){
                this.setCurrentPage();
            }
        },
        methods: {
        	...mapMutations([
        	]),
        	...mapActions([
        	'fetchMonitorListAction'
        	]),
            show (index) {
               /* this.$Modal.info({
                    title: '用户信息',
                    content: `姓名：${this.data6[index].name}<br>年龄：${this.data6[index].age}<br>地址：${this.data6[index].address}`
                }) */
            },
            setCurrentPage(index){
                this.indexPage = index?index:1;
                var startPage = (Number(this.indexPage)-1)*this.pageLength;
                var endPage = (Number(this.indexPage))*this.pageLength;
                this.pageData = this.monitor.list.slice(startPage, endPage);
                return this.pageData;
            },
            getData(){
            	this.fetchMonitorListAction()
            },
            goDetail(data){
                console.log(data);
                this.$router.push({name:'demo',query:{name:"demo"}});
            },
            changePage(pageSize){
                this.pageLength=Number(pageSize);
                this.setCurrentPage();
            }
        }
    }
</script>