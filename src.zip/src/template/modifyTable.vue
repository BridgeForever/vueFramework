<template>
	<div>
	<p>{{title}}</p>
  
    </div>
</template>
<script>
    export default {
        data () {
            return {
                
            }
        },
        props:[
        'title'
        ]
    }
</script>