<template>
    <div>

        <myMenu></myMenu>
       
    </div>
</template>
<script>
import myMenu from './template/menu'
    export default {
        data() {
            return {

            };
        },
        components:{
            myMenu
        },
        mounted() {

        },
        beforeDestroy() {

        },
        methods: {

        }
    };
</script>