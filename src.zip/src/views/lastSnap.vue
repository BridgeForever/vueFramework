<template>
    <div >
    <Dropdown style="margin-left: 20px" @on-click="downLoad">
        <Button type="primary">
            下拉菜单
            <Icon type="arrow-down-b"></Icon>
        </Button>
        <Dropdown-menu slot="list"  >
            <Dropdown-item>驴打滚</Dropdown-item>
            <Dropdown-item>炸酱面</Dropdown-item>
            <Dropdown-item disabled>豆汁儿</Dropdown-item>
            <Dropdown-item>冰糖葫芦</Dropdown-item>
            <Dropdown-item divided>北京烤鸭</Dropdown-item>
        </Dropdown-menu>
    </Dropdown>
     <Modal
        v-model="modal1"
        title="普通的Modal对话框标题"
          @on-ok="ok"
       >
        <p >对话框内容</p>
        <p>对话框内容</p>
        <p>对话框内容</p>
    </Modal>
    
    <subModel :modal1="modal2"></subModel>
    </div>
</template>
<script>
import util from '../libs/util';
import { mapState, mapGetters, mapMutations, mapActions } from 'vuex';
import subModel from '../template/model';
    export default {
        data(){
            return {
                modal1:true,
                modal2:false,
                modal2Style:{
                    marginTop:"100px"
                }
            }
        },
        methods:{
        	 downLoad(){
                util.ajax('/monitor/weixin/download',{
                    headers:{
                        'Content-Type':'application/octet-stream'
                    }

                }).then((res)=>{
                    console.log(res)
                   window.location.href=res

                }).catch((error)=>{
                 console.log(error)
                })
            },
            ...mapMutations([
            'CHANGE_MENU_NAV'
            ]),
            ok () {
                this.$Message.info('点击了确定');
                this.modal2=true;
            },
        },
        created(){
         const data=[
            {
            'href':'#',
            'name':'主页'

            },
            {
            'href':'monitor',
            'name':'通讯录快照'
            }
            ]
            this.CHANGE_MENU_NAV(data);

        },
        components:{
            subModel
        }
      
    }
</script>