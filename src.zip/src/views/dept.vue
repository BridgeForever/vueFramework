<style scoped>
   
</style>
<template>
    <div id="dept">
       /*<pageDemo></pageDemo>*/
       <table class="table table-striped jambo_table">
            <thead>
            <tr>
                <th>测试1</th>
                <th>测试2</th>
                <th>测试3</th>
            </tr>
            </thead>
            <tbody>
               {{initTable()}}
            </tbody>

       </table>
    </div>
</template>
<script>
import { mapState, mapGetters, mapMutations, mapActions } from 'vuex';
import pageDemo from '../views/pageDemo';

    export default {
        data(){
            return {

            }
        },
        computed:{
            ...mapState([
            'monitor'
            ])
        },
        components:{
        pageDemo
        },
         created(){
            this.getData();
           
        },
         methods: {
           
            ...mapActions([
            'fetchMonitorListAction'
            ]),
           
            getData(){
                this.fetchMonitorListAction()
            },
            initTable(){
                console.log(this.monitor.list)
            }
            
        }
    };
</script>