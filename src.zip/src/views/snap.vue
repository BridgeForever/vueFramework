<style scoped>
   
</style>
<template>
    <div id="snap">
        <commonPage :columns="columns7" :pageLength="pageLength" :totalPage="totalPage" :tableData="tableData" searching=true></commonPage>
        <p>{{totalLength}}</p>
    </div>
</template>
<script>
import commonPage from '../template/commonPage';
import { mapState, mapGetters, mapMutations, mapActions } from 'vuex';
    export default {
    	data(){
    		return {
    			 totalPage:0,
    			 pageLength:100,
    			 columns7: [
                    {
                        title:'序号',
                        key:'snapUserFullName',
                        render:(h,params)=>{
                            return params.index+1
                        }

                    },
                    {
                        title: '姓名',
                        key: 'snapUserFullName',
                        render: (h, params) => {
                            return h('div', [
                                h('Icon', {
                                    props: {
                                        type: 'person'
                                    }
                                }),
                                h('strong', params.row.snapUserFullName)
                            ]);
                        }
                    },
                    {
                        title: '部门',
                        key: 'snapDept'
                    },
                    {
                        title: '职位',
                        key: 'snapPost'
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 150,
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h('Button', {
                                    props: {
                                        type: 'primary',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            this.show(params.index)
                                        }
                                    }
                                }, '查看'),
                                h('Button', {
                                    props: {
                                        type: 'error',
                                        size: 'small'
                                    },
                                    on: {
                                        click: () => {
                                            this.remove(params.index)
                                        }
                                    }
                                }, '删除'),
                                h('Dropdown',
                                {
                                	props:{
                                		trigger:"click"
                                	},
                                	on:{
                                	'on-click':()=>{
                                	console.log(1);
                                	}
                                	},
                                	style:{marginLeft:"20px"}
                                },
                                [
                                	h('Button',{
                                		props: {
                                        type: 'primary'
                                   		 }
                                	},'下拉'),
                                	h('Dropdown-menu',
                                	{
                                		slot:"list"
                                		
                                	},[
                                	  h('Dropdown-item',{

                                	  },
                                	  '下拉项')
                                	])
                                ])

                            ]);
                        }
                    }
                ],
                tableData:[]
    		}
    	},
        methods: {
           ...mapActions([
        	'fetchMonitorListAction'
        	]),
        	 getData(){
            	this.fetchMonitorListAction()
            }
        },
        computed:{
        	...mapState([
        	'monitor'
        	]),
            
        	totalLength(){
        		this.totalPage=this.monitor.list.length;
        		this.tableData=this.monitor.list;
        	return this.monitor.list.length

        	}
        },
        components:{
        	commonPage
        },
         created(){
        	this.getData();
        }
    };
</script>