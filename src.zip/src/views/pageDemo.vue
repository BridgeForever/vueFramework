<style scoped>

    .page-item{
        width: 24px;
        text-align: center;
        line-height: 24px;
        border-left: 1px solid #c1c1c1;
        display: inline-block;
        cursor:pointer;
    }
    .page-item:first-child{
        border-left: none;
    }

    #c-page{
        margin-top: 10px;
        float: left;
        border: 1px solid #c1c1c1;
    }
</style>
<template>
	<div id="monitor">
    <Table border :columns="columns7" v-bind:data="pageData" ></Table>
     <commonPage  :pageLength="pageLength" :tableData="tableData"></commonPage>
    </div>
</template>
<script>
import { mapState, mapGetters, mapMutations, mapActions } from 'vuex';
import commonPage from '../template/panigation';
    export default {
        data () {
            return {
                pageData:[],
                pageLength:100,
                pageOpts:[
                10,20,50,100
                ],
                columns7: [
                    {
                        title:'序号',
                        key:'snapUserFullName',
                        render:(h,params)=>{
                            return params.index+1
                        }

                    },
                    {
                        title: '姓名',
                        key: 'snapUserFullName',
                        render: (h, params) => {
                            return h('div', [
                                h('Icon', {
                                    props: {
                                        type: 'person'
                                    }
                                }),
                                h('strong', params.row.snapUserFullName)
                            ]);
                        }
                    },
                    {
                        title: '部门',
                        key: 'snapDept'
                    },
                    {
                        title: '职位',
                        key: 'snapPost'
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 150,
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h('Button', {
                                    props: {
                                        type: 'primary',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            this.show(params.index)
                                        }
                                    }
                                }, '查看'),
                                h('Button', {
                                    props: {
                                        type: 'error',
                                        size: 'small'
                                    },
                                    on: {
                                        click: () => {
                                            this.remove(params.index)
                                        }
                                    }
                                }, '删除'),
                                h('Dropdown',
                                {
                                	props:{
                                		trigger:"click"
                                	},
                                	on:{
                                	'on-click':()=>{
                                	console.log(1);
                                	}
                                	},
                                	style:{marginLeft:"20px"}
                                },
                                [
                                	h('Button',{
                                		props: {
                                        type: 'primary'
                                   		 }
                                	},'下拉'),
                                	h('Dropdown-menu',
                                	{
                                		slot:"list"
                                		
                                	},[
                                	  h('Dropdown-item',{

                                	  },
                                	  '下拉项')
                                	])
                                ])

                            ]);
                        }
                    }
                ]
            }
        },
         computed:{
            ...mapState([
            'monitor'
            ]),
            
            totalLength(){
            return this.monitor.list.length

            }, 
            tableData(){
            return this.monitor.list;

            },
            
            fetData(){
                return this.pageData;
            }
        },
        created(){
            this.getData();
        },
        methods: {
            ...mapMutations([
            ]),
            ...mapActions([
            'fetchMonitorListAction'
            ]),
           
            getData(){
                this.fetchMonitorListAction()
            }
        },
        components:{
        commonPage
        }

    }
</script>