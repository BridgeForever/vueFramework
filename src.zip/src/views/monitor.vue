<template>
	<div id="monitor">
        <Button type="primary">修改</Button>
        <Button type="ghost">刷新</Button>
        <monitorTable></monitorTable>
        <modifyTable  :title="message"></modifyTable>
        <model v-on:myClick="clickBack" title="组件传值测试"></model>
    </div>
</template>
<script>
import monitorTable from '../template/monitorTable';
import modifyTable from '../template/modifyTable';
import model from '../template/model';
import { mapState, mapGetters, mapMutations, mapActions } from 'vuex';
    export default {
       data(){
        return {
            message:"hello",
            clickBack:function(){
                console.log(2222)
            }
        }
       },
        computed:{
        	...mapState([
        	'monitor'
        	]),
        	...mapGetters([
            'MONITOR_LENGTH'
            ])
        },
        beforeCreate(){

        },
        created(){
        	//this.getData();
            const data=[
            {
            'href':'#',
            'name':'主页'

            },
            {
            'href':'monitor',
            'name':'通讯录'
            }
            ]
            this.CHANGE_MENU_NAV(data);

        },
        components:{
            monitorTable,
            modifyTable,
            model
        },
        methods: {
        	...mapMutations([
            'CHANGE_MENU_NAV'
        	]),
        	...mapActions([
        	'fetchMonitorListAction'
        	]),
            show (index) {
               /* this.$Modal.info({
                    title: '用户信息',
                    content: `姓名：${this.data6[index].name}<br>年龄：${this.data6[index].age}<br>地址：${this.data6[index].address}`
                }) */
            },
            remove (index) {
               // this.data6.splice(index, 1);
            },
            getData(){
            	this.fetchMonitorListAction()
            },
            changePage(page){

            },
            handlerClick(){
            //回调
                this.$Message.info("点击了按钮")
            }
        }
    }
</script>