import Vue from 'vue';
import Vuex from 'vuex';
Vue.use(Vuex);
import menu from './modules/menu';
import monitor from './modules/monitor';
const store = new Vuex.Store({
    modules:{
    	menu,
    	monitor
    }
});
export default store
