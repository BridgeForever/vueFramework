import {menuMutations} from '../mutations/menu';
import {menuActions} from '../actions/menu';
 const menu={
	state:{
		menuList:[],
		activeMenu:"monitor",
		pathNav:[{
			href:'#',
			name:'主页'
		},{
			href:'monitor',
			name:'通讯录'
		}

		]
	},
	 mutations:menuMutations,
	actions:menuActions
}
export default menu