import axios from 'axios'
export const menuActions={
	 fetchMenuAction({ commit, state, dispatch }, params) {
       axios({
            method: 'get',
            url: 'menu.config.js',
           
        }).then((res) => {
            commit(types.CHANGE_MENU_LIST, {
                data: res.menuConfig.menuList
            })
        }).catch((error) => {
           
            console.log(error);
        })
    }
}