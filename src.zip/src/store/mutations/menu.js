import * as types from '../constants/types'
export const menuMutations={
	[types.CHANGE_MENU_LIST](state,action){
		state.menuList=action.data
		
	},
	[types.CHANGE_MENU_ACTIVE](state,action){
		state.activeMenu=action
	},
	[types.CHANGE_MENU_NAV](state,action){
		state.pathNav=action
	}
}
