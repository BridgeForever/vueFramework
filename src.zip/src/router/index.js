import Vue from 'vue';
import VueRouter from 'vue-router';
Vue.use(VueRouter);
const routers = [{
    path: '/index',
    name:'index',
    component: (resolve) => require(['../views/index.vue'], resolve)
}];

// 路由配置
const RouterConfig = {
    mode: 'history',
    routes: routers
};
const router = new VueRouter(RouterConfig);
//router.push({name:'index'});

router.beforeEach((to, from, next) => {
   // iView.LoadingBar.start();
    //Util.title(to.meta.title);
    next();
});

router.afterEach(() => {
   // iView.LoadingBar.finish();
    window.scrollTo(0, 0);
});
export default router;