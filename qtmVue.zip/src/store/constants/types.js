/*main*/
export const CHANGE_MAIN_COUNT = 'CHANGE_MAIN_COUNT';