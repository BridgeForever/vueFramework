const routers = [
// {
// 	 path: '*', redirect: '/login' 
// },
// {
// 	name:'login',
// 	path:'/login',
// 	component:(resolve) => require(['./views/login.vue'],resolve)
// },
// {
// 	name:'monitor',
//     path: '/monitor',
//     meta: {
//         title: ''
//     },
//     component: (resolve) => require(['./views/monitor.vue'], resolve)
// },{
// 	path:'/snap',
// 	name:'snap',
// 	component:(resolve)=>require(['./views/snap.vue'],resolve)
// },{
// 	path:'/lastSnap',
// 	name:'lastSnap',
// 	component:(resolve)=>require(['./views/lastSnap.vue'],resolve)
// },{
// 	path:'/dept',
// 	name:'dept',
// 	component:(resolve)=>require(['./views/dept.vue'],resolve)
// },{
// 	path:'/second',
// 	name:'second',
// 	component:(resolve)=>require(['./template/second.vue'],resolve)
// }
];
export default routers;