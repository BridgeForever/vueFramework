export const menuConfig = {
    "menuHref": "#/monitor?lv0path=通讯录监控",
    "menuIcon": "fa fa-address-book",
    "menuName": "长安通讯录服务",
    "menuList": [
        {
            "menuItemHref": "monitor",
            "menuItemIcon": "fa fa-camera",
            "menuItemName": "通讯录对比数据",
            "menuName":"monitor",
            "menuList": [
                
            ]
        },
        {
            "menuItemHref": "monitor",
            "menuItemIcon": "fa fa-dashboard",
            "menuItemName": "通讯录对比数据",
            "menuName":"monitorP",
            "menuList": [
                 {
                    "menuItemHref": "#/lastSnap?lv0path=通讯录当前快照",
                "menuItemIcon": "fa fa-camera",
                "menuItemName": "二级菜单",
                "menuName":"secondP",
                "menuList": [
                        
                ]
                 },
                 {
                    "menuItemHref": "#/lastSnap?lv0path=通讯录当前快照",
                "menuItemIcon": "fa fa-camera",
                "menuItemName": "二级",
                "menuName":"second",
                "menuList": [
                       
                ]
                 }
            ]
        },
        {
            "menuItemHref": "lastSnap",
            "menuItemIcon": "fa fa-camera",
            "menuItemName": "通讯录当前快照",
            "menuName":"lastSnap",
            "menuList": [
                
            ]
        },
        {
            "menuItemHref": "snap",
            "menuItemIcon": "fa fa-camera-retro",
            "menuItemName": "通讯录快照",
            "menuName":"snap",
            "menuList": [
                
            ] 
        },
        {
            "menuItemHref": "dept",
            "menuItemIcon": "fa fa-wrench",
            "menuItemName": "兼职部门维护",
            "menuName":"dept",
            "menuList": [
                
            ]
        }

    ]
}
